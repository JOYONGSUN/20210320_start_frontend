/*fetch 주소 형식의 함수를 사용할수 있음
https://developer.mozilla.org/ko/docs/Web/API/Fetch_API/Using_Fetch
fetch('http://example.com/movies.json')
  .then(function(response) {
    return response.json();
  })
  .then(function(myJson) {
    console.log(JSON.stringify(myJson));
  });
*/
/*parse
*/
/*메소드 체이닝 : 함수 연달아 연결해서 씀
fetch().then().then()
*/
/*Body.json()
https://developer.mozilla.org/ko/docs/Web/API/Body/json
*/
/*JSON.stringify():실제데이터 출력할수 있는 모습으로 변환
https://developer.mozilla.org/ko/docs/Web/JavaScript/Reference/Global_Objects/JSON/stringify
*/
/*객체쓰는 방법
person.name
paerson[name]
*/
/*웨더이미지로 돔 만들기
var 옛날 자바스크립트버전 let 최근
따옴표는 문자지 변수가아님
강사님은 html에서는 "" js 에서는 ''
*/
/*자바스크립트 소수점 자르기
https://wdevp.tistory.com/59
Math.ceil() : 소수점 올림, 정수 반환
Math.floor() : 소수점 버림, 정수 반환
Math.round() : 소수점 반올림, 정수 반환
*/
let weatherImage=document.querySelector('.weather-image');
let weatherText=document.querySelector('.weather-text');
let weatherTempCurrent=document.querySelector('.weather-temp-current');
let weatherTempMin=document.querySelector('.weather-temp-minmax .min');
let weatherTempMax=document.querySelector('.weather-temp-minmax .max');


fetch('https://api.openweathermap.org/data/2.5/weather?q=Seoul&appid=078ffadd92b07bd9abc7aa9eed16c9ac')
    .then(function(response) {
        return response.json();
    })
    .then(function(myJson) {
        console.log(myJson);
        console.log(myJson.weather[0].icon);
        console.log(myJson.weather[0].main);
        console.log=Math.floor(myJson.main.temp - 273.15);/*수정필요*/
        console.log=Math.floor(myJson.main.temp_max - 273.15);/*수정필요*/
        console.log=Math.floor(myJson.main.temp_min - 273.15);/*수정필요*/
        /*console.log(myJson);출력이목적*/
        /*console.log(JSON.stringify(myJson));데이터사용목적*/

        //10, 21 => 1021로 표시하고 싶음 || 10+21 => 31 || '10'+'21' => 1021 연결연산
        weatherImage.src='../images/'+ myJson.weather[0].icon +'@2x.png';
        /*weatherImage.src='../images/'+ 01d +'@2x.png';문자열과 변수,문자열과 값을 연결*/

        weatherText.innerHTML=myJson.weather[0].main;

        weatherTempCurrent.innerHTML=myJson.main.temp - 273.15;

        weatherTempMin.innerHTML=myJson.main.temp_min - 273.15;

        weatherTempMax.innerHTML=myJson.main.temp_min - 273.15;

    });